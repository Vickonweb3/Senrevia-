# Senrivia architecture

## Components

1. **Telegram bot** (`bot/`) — python-telegram-bot, inline menus, commands  
2. **MongoDB** (`database/`) — users, watchlist, trails, scrape log  
3. **Scraper** (`scraper/`) — async fxTwitter profile / replies / following  
4. **Worker** (`workers/scheduler.py`) — interval scan of active watches  
5. **Admin dashboard** (`admin/dashboard.py`) — FastAPI, secret-protected HTML + JSON  

## Data model (Mongo)

### users
- `telegram_id` (unique)
- `username`, `first_name`, `last_name`
- `joined_at`, `last_active_at`
- `settings.alerts_enabled`

### watchlist
- `telegram_id` + `handle_lower` (unique pair)
- `handle`, `display_name`, `avatar_url`, `followers_count`
- `paused` (bool)
- `added_at`, `last_scanned_at`, `last_error`

### trails
- `event_id` (unique)
- `kind`: `reply` | `follow`
- `handle`, reply/follow payload
- `is_new`, `baseline`
- `created_at`

## Pause / resume

Paused rows remain on the user’s list but are excluded from `list_active_watch_handles()`, so the worker skips them until resumed.
