from telegram.ext import Application

from . import admin, alerts, analytics, search, settings, start, trails, watchlist


def register_handlers(app: Application) -> None:
    start.register(app)
    search.register(app)
    watchlist.register(app)
    trails.register(app)
    alerts.register(app)
    analytics.register(app)
    settings.register(app)
    admin.register(app)
