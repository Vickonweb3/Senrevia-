"""Start and home menu handlers."""

from __future__ import annotations

from telegram import Update
from telegram.constants import ParseMode
from telegram.ext import Application, CallbackQueryHandler, CommandHandler, ContextTypes, MessageHandler, filters

from bot.keyboards.menus import main_menu, reply_home_keyboard
from database import repositories as repo

WELCOME = (
    "👋 *Welcome to Senrivia*\n"
    "\n"
    "_Where influencers leave a trail._\n"
    "\n"
    "Track public influencer activity on X — the replies they leave "
    "and the accounts they begin following — as a clear, living trail.\n"
    "\n"
    "What would you like to do?"
)


async def cmd_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user = update.effective_user
    if not user or not update.message:
        return
    repo.upsert_user(
        user.id,
        username=user.username,
        first_name=user.first_name,
        last_name=user.last_name,
        language_code=user.language_code,
    )
    await update.message.reply_text(
        WELCOME,
        parse_mode=ParseMode.MARKDOWN,
        reply_markup=main_menu(),
    )
    await update.message.reply_text(
        "Quick actions stay on your keyboard for faster navigation.",
        reply_markup=reply_home_keyboard(),
    )


async def menu_home(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    if not query:
        return
    await query.answer()
    user = update.effective_user
    if user:
        repo.upsert_user(
            user.id,
            username=user.username,
            first_name=user.first_name,
            last_name=user.last_name,
            language_code=user.language_code,
        )
    await query.edit_message_text(
        WELCOME,
        parse_mode=ParseMode.MARKDOWN,
        reply_markup=main_menu(),
    )


async def text_nav(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Map persistent reply keyboard labels to menu actions."""
    if not update.message or not update.message.text:
        return
    text = update.message.text.strip()
    mapping = {
        "🔎 Search": "search",
        "👤 My Influencers": "watchlist",
        "🧵 Trails": "trails",
        "📊 Analytics": "analytics",
        "⚙️ Settings": "settings",
    }
    action = mapping.get(text)
    if not action:
        return
    # Reuse message-style responses via context flag
    context.user_data["nav"] = action
    if action == "search":
        from .search import prompt_search

        await prompt_search(update, context)
    elif action == "watchlist":
        from .watchlist import show_watchlist_message

        await show_watchlist_message(update, context)
    elif action == "trails":
        from .trails import show_trails_message

        await show_trails_message(update, context)
    elif action == "analytics":
        from .analytics import show_analytics_message

        await show_analytics_message(update, context)
    elif action == "settings":
        from .settings import show_settings_message

        await show_settings_message(update, context)


def register(app: Application) -> None:
    app.add_handler(CommandHandler("start", cmd_start))
    app.add_handler(CommandHandler("menu", cmd_start))
    app.add_handler(CallbackQueryHandler(menu_home, pattern=r"^menu:home$"))
    app.add_handler(
        MessageHandler(
            filters.TEXT
            & ~filters.COMMAND
            & filters.Regex(r"^(🔎 Search|👤 My Influencers|🧵 Trails|📊 Analytics|⚙️ Settings)$"),
            text_nav,
        )
    )
