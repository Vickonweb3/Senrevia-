"""Admin-only Telegram commands and menus."""

from __future__ import annotations

from telegram import Update
from telegram.constants import ParseMode
from telegram.ext import Application, CallbackQueryHandler, CommandHandler, ContextTypes

from bot.config import get_settings
from bot.keyboards.menus import admin_menu, back_main
from database import repositories as repo


def _guard(update: Update) -> bool:
    user = update.effective_user
    return bool(user and get_settings().is_admin(user.id))


async def cmd_admin(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not update.message:
        return
    if not _guard(update):
        await update.message.reply_text("This command is restricted to administrators.")
        return
    await update.message.reply_text(
        "🛡 *Admin Console*\n\nMonitor adoption, tracking load, and system health.",
        parse_mode=ParseMode.MARKDOWN,
        reply_markup=admin_menu(),
    )


async def admin_overview(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    if not query:
        return
    if not _guard(update):
        await query.answer("Restricted", show_alert=True)
        return
    await query.answer()
    stats = repo.admin_stats()
    text = (
        "📈 *Admin Overview*\n"
        "\n"
        f"Users joined: *{stats['users_total']}*\n"
        f"Watchlist rows: *{stats['watch_total']}*\n"
        f"Active watches: *{stats['watch_active']}*\n"
        f"Paused watches: *{stats['watch_paused']}*\n"
        f"Trail events stored: *{stats['trails_total']}*\n"
        "\n"
        "Open the web dashboard for full tables and filters."
    )
    settings = get_settings()
    if settings.admin_public_url:
        text += f"\n\nDashboard: {settings.admin_public_url}"
    await query.edit_message_text(
        text, parse_mode=ParseMode.MARKDOWN, reply_markup=admin_menu()
    )


async def admin_users(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    if not query:
        return
    if not _guard(update):
        await query.answer("Restricted", show_alert=True)
        return
    await query.answer()
    users = repo.list_users(limit=15)
    if not users:
        body = "_No users yet._"
    else:
        lines = []
        for u in users:
            uname = f"@{u['username']}" if u.get("username") else (u.get("first_name") or "—")
            lines.append(f"• `{u.get('telegram_id')}` {uname}")
        body = "\n".join(lines)
    await query.edit_message_text(
        f"👥 *Recent users*\n\n{body}",
        parse_mode=ParseMode.MARKDOWN,
        reply_markup=admin_menu(),
    )


async def admin_top(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    if not query:
        return
    if not _guard(update):
        await query.answer("Restricted", show_alert=True)
        return
    await query.answer()
    stats = repo.admin_stats()
    top = stats.get("top_tracked") or []
    if not top:
        body = "_No tracked accounts yet._"
    else:
        body = "\n".join(
            f"{i}. @{row.get('handle')} — *{row.get('count')}* watchers"
            for i, row in enumerate(top, start=1)
        )
    await query.edit_message_text(
        f"🎯 *Most tracked*\n\n{body}",
        parse_mode=ParseMode.MARKDOWN,
        reply_markup=admin_menu(),
    )


async def cmd_stats(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not update.message:
        return
    if not _guard(update):
        await update.message.reply_text("Restricted.")
        return
    stats = repo.admin_stats()
    await update.message.reply_text(
        (
            f"Users: {stats['users_total']}\n"
            f"Active watches: {stats['watch_active']}\n"
            f"Trails: {stats['trails_total']}"
        ),
        reply_markup=back_main(),
    )


def register(app: Application) -> None:
    app.add_handler(CommandHandler("admin", cmd_admin))
    app.add_handler(CommandHandler("stats", cmd_stats))
    app.add_handler(CallbackQueryHandler(admin_overview, pattern=r"^admin:overview$"))
    app.add_handler(CallbackQueryHandler(admin_users, pattern=r"^admin:users$"))
    app.add_handler(CallbackQueryHandler(admin_top, pattern=r"^admin:top$"))
