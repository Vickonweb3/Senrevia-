"""My Influencers / watchlist handlers."""

from __future__ import annotations

from telegram import Update
from telegram.constants import ParseMode
from telegram.ext import Application, CallbackQueryHandler, CommandHandler, ContextTypes

from bot.keyboards.menus import back_main, watchlist_item_actions, watchlist_menu
from database import repositories as repo
from services.influencer import format_followers, watchlist_status_emoji


def _render_list(entries: list) -> str:
    if not entries:
        return (
            "👤 *My Influencers*\n"
            "\n"
            "Your watchlist is empty.\n"
            "Search for a public username to begin mapping their trail."
        )
    lines = ["👤 *My Influencers*\n"]
    for i, entry in enumerate(entries, start=1):
        mark = watchlist_status_emoji(entry)
        state = "Paused" if entry.get("paused") else "Active"
        handle = entry.get("handle")
        lines.append(f"{i}. {mark} *@{handle}* — {state}")
    lines.append("\nTap an account to pause, resume, or remove.")
    return "\n".join(lines)


async def show_watchlist_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user = update.effective_user
    if not user or not update.message:
        return
    entries = repo.list_watchlist(user.id)
    await update.message.reply_text(
        _render_list(entries),
        parse_mode=ParseMode.MARKDOWN,
        reply_markup=watchlist_menu(entries),
    )


async def show_watchlist(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    user = update.effective_user
    if not query or not user:
        return
    await query.answer()
    entries = repo.list_watchlist(user.id)
    await query.edit_message_text(
        _render_list(entries),
        parse_mode=ParseMode.MARKDOWN,
        reply_markup=watchlist_menu(entries),
    )


async def open_item(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    user = update.effective_user
    if not query or not query.data or not user:
        return
    handle = query.data.split(":", 1)[1]
    await query.answer()
    entries = repo.list_watchlist(user.id)
    entry = next((e for e in entries if e.get("handle_lower") == handle.lower()), None)
    if not entry:
        await query.edit_message_text(
            "That account is no longer on your watchlist.",
            reply_markup=back_main(),
        )
        return
    paused = bool(entry.get("paused"))
    followers = format_followers(entry.get("followers_count"))
    status = "Paused" if paused else "Active"
    text = (
        f"👤 *@{entry.get('handle')}*\n"
        f"{entry.get('display_name') or entry.get('handle')}\n"
        f"\n"
        f"Status: *{status}*\n"
        f"Followers: *{followers}*\n"
        f"Added: {entry.get('added_at')}\n"
    )
    if entry.get("last_error"):
        text += f"\nLast issue: _{entry['last_error']}_"
    await query.edit_message_text(
        text,
        parse_mode=ParseMode.MARKDOWN,
        reply_markup=watchlist_item_actions(entry["handle"], paused=paused),
    )


async def pause_watch(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    user = update.effective_user
    if not query or not query.data or not user:
        return
    handle = query.data.split(":", 1)[1]
    entry = repo.set_watch_paused(user.id, handle, True)
    await query.answer("Tracking paused")
    if not entry:
        await query.edit_message_text("Account not found on your list.", reply_markup=back_main())
        return
    await query.edit_message_text(
        f"⏸ Tracking paused for *@{entry['handle']}*.\n\nResume anytime from My Influencers.",
        parse_mode=ParseMode.MARKDOWN,
        reply_markup=watchlist_item_actions(entry["handle"], paused=True),
    )


async def resume_watch(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    user = update.effective_user
    if not query or not query.data or not user:
        return
    handle = query.data.split(":", 1)[1]
    entry = repo.set_watch_paused(user.id, handle, False)
    await query.answer("Tracking resumed")
    if not entry:
        await query.edit_message_text("Account not found on your list.", reply_markup=back_main())
        return
    await query.edit_message_text(
        f"▶️ Tracking resumed for *@{entry['handle']}*.",
        parse_mode=ParseMode.MARKDOWN,
        reply_markup=watchlist_item_actions(entry["handle"], paused=False),
    )


async def unwatch(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    user = update.effective_user
    if not query or not query.data or not user:
        return
    handle = query.data.split(":", 1)[1]
    ok = repo.remove_from_watchlist(user.id, handle)
    await query.answer("Removed" if ok else "Not found")
    entries = repo.list_watchlist(user.id)
    await query.edit_message_text(
        ("Removed from your watchlist.\n\n" + _render_list(entries)),
        parse_mode=ParseMode.MARKDOWN,
        reply_markup=watchlist_menu(entries),
    )


def register(app: Application) -> None:
    app.add_handler(CommandHandler("watchlist", show_watchlist_message))
    app.add_handler(CallbackQueryHandler(show_watchlist, pattern=r"^menu:watchlist$"))
    app.add_handler(CallbackQueryHandler(open_item, pattern=r"^wlitem:"))
    app.add_handler(CallbackQueryHandler(pause_watch, pattern=r"^pause:"))
    app.add_handler(CallbackQueryHandler(resume_watch, pattern=r"^resume:"))
    app.add_handler(CallbackQueryHandler(unwatch, pattern=r"^unwatch:"))
