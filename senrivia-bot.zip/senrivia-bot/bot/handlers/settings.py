"""Settings handlers."""

from __future__ import annotations

from telegram import Update
from telegram.constants import ParseMode
from telegram.ext import Application, CallbackQueryHandler, CommandHandler, ContextTypes

from bot.keyboards.menus import settings_menu
from database import repositories as repo


def _alerts_on(user_id: int) -> bool:
    doc = repo.get_user(user_id) or {}
    return bool((doc.get("settings") or {}).get("alerts_enabled", True))


async def show_settings_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user = update.effective_user
    if not user or not update.message:
        return
    on = _alerts_on(user.id)
    text = (
        "⚙️ *Settings*\n"
        "\n"
        "Control how Senrivia notifies you and how tracking behaves.\n"
        "Pause individual accounts from *My Influencers*."
    )
    await update.message.reply_text(
        text, parse_mode=ParseMode.MARKDOWN, reply_markup=settings_menu(alerts_on=on)
    )


async def show_settings(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    user = update.effective_user
    if not query or not user:
        return
    await query.answer()
    on = _alerts_on(user.id)
    await query.edit_message_text(
        "⚙️ *Settings*\n\nControl notifications and tracking preferences.",
        parse_mode=ParseMode.MARKDOWN,
        reply_markup=settings_menu(alerts_on=on),
    )


async def toggle_alerts(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    user = update.effective_user
    if not query or not user:
        return
    current = _alerts_on(user.id)
    repo.update_user_settings(user.id, {"alerts_enabled": not current})
    on = not current
    await query.answer("Alerts on" if on else "Alerts off")
    await query.edit_message_text(
        "⚙️ *Settings*\n\n"
        + ("Notifications enabled." if on else "Notifications paused."),
        parse_mode=ParseMode.MARKDOWN,
        reply_markup=settings_menu(alerts_on=on),
    )


def register(app: Application) -> None:
    app.add_handler(CommandHandler("settings", show_settings_message))
    app.add_handler(CallbackQueryHandler(show_settings, pattern=r"^menu:settings$"))
    app.add_handler(CallbackQueryHandler(toggle_alerts, pattern=r"^settings:toggle_alerts$"))
