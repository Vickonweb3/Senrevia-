"""Senrivia Telegram bot package."""
__version__ = "1.0.0"
