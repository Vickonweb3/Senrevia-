"""Application factory for the Telegram bot."""

from __future__ import annotations

import logging

from telegram.ext import Application

from bot.config import get_settings
from bot.handlers import register_handlers
from database import close_db, init_db
from workers.scheduler import start_scheduler, stop_scheduler

log = logging.getLogger("senrivia")


async def on_startup(app: Application) -> None:
    init_db()
    start_scheduler(app)
    log.info("Senrivia bot online")


async def on_shutdown(app: Application) -> None:
    stop_scheduler()
    close_db()
    log.info("Senrivia bot stopped")


def build_application() -> Application:
    settings = get_settings()
    settings.validate()
    app = (
        Application.builder()
        .token(settings.bot_token)
        .post_init(on_startup)
        .post_shutdown(on_shutdown)
        .build()
    )
    register_handlers(app)
    return app
