"""Inline and reply keyboards for Senrivia."""

from __future__ import annotations

from telegram import InlineKeyboardButton, InlineKeyboardMarkup, KeyboardButton, ReplyKeyboardMarkup


def main_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        [
            [InlineKeyboardButton("🔎 Search Influencer", callback_data="menu:search")],
            [
                InlineKeyboardButton("👤 My Influencers", callback_data="menu:watchlist"),
                InlineKeyboardButton("🧵 View Trails", callback_data="menu:trails"),
            ],
            [
                InlineKeyboardButton("🔔 Alerts", callback_data="menu:alerts"),
                InlineKeyboardButton("📊 Analytics", callback_data="menu:analytics"),
            ],
            [InlineKeyboardButton("⚙️ Settings", callback_data="menu:settings")],
        ]
    )


def back_main() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        [[InlineKeyboardButton("← Main menu", callback_data="menu:home")]]
    )


def influencer_actions(handle: str, *, watching: bool) -> InlineKeyboardMarkup:
    rows = []
    if watching:
        rows.append(
            [
                InlineKeyboardButton("🧵 View Trail", callback_data=f"trail:{handle}"),
                InlineKeyboardButton("⏸ Pause", callback_data=f"pause:{handle}"),
            ]
        )
        rows.append(
            [InlineKeyboardButton("🗑 Remove", callback_data=f"unwatch:{handle}")]
        )
    else:
        rows.append(
            [InlineKeyboardButton("👁 Watch", callback_data=f"watch:{handle}")]
        )
        rows.append(
            [InlineKeyboardButton("🧵 Preview Trail", callback_data=f"trail:{handle}")]
        )
    rows.append([InlineKeyboardButton("← Main menu", callback_data="menu:home")])
    return InlineKeyboardMarkup(rows)


def watchlist_item_actions(handle: str, *, paused: bool) -> InlineKeyboardMarkup:
    toggle = (
        InlineKeyboardButton("▶️ Resume", callback_data=f"resume:{handle}")
        if paused
        else InlineKeyboardButton("⏸ Pause", callback_data=f"pause:{handle}")
    )
    return InlineKeyboardMarkup(
        [
            [
                InlineKeyboardButton("🧵 Trail", callback_data=f"trail:{handle}"),
                toggle,
            ],
            [
                InlineKeyboardButton("🗑 Remove", callback_data=f"unwatch:{handle}"),
                InlineKeyboardButton("← Watchlist", callback_data="menu:watchlist"),
            ],
        ]
    )


def watchlist_menu(entries: list) -> InlineKeyboardMarkup:
    rows = []
    for entry in entries[:20]:
        handle = entry.get("handle") or "?"
        paused = bool(entry.get("paused"))
        mark = "⏸" if paused else "🟢"
        rows.append(
            [
                InlineKeyboardButton(
                    f"{mark} @{handle}",
                    callback_data=f"wlitem:{handle}",
                )
            ]
        )
    rows.append([InlineKeyboardButton("➕ Add influencer", callback_data="menu:search")])
    rows.append([InlineKeyboardButton("← Main menu", callback_data="menu:home")])
    return InlineKeyboardMarkup(rows)


def settings_menu(*, alerts_on: bool) -> InlineKeyboardMarkup:
    alert_label = "🔔 Alerts: On" if alerts_on else "🔕 Alerts: Off"
    return InlineKeyboardMarkup(
        [
            [InlineKeyboardButton(alert_label, callback_data="settings:toggle_alerts")],
            [InlineKeyboardButton("← Main menu", callback_data="menu:home")],
        ]
    )


def admin_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        [
            [InlineKeyboardButton("📈 Overview", callback_data="admin:overview")],
            [InlineKeyboardButton("👥 Recent users", callback_data="admin:users")],
            [InlineKeyboardButton("🎯 Top tracked", callback_data="admin:top")],
            [InlineKeyboardButton("← Main menu", callback_data="menu:home")],
        ]
    )


def reply_home_keyboard() -> ReplyKeyboardMarkup:
    return ReplyKeyboardMarkup(
        [
            [KeyboardButton("🔎 Search"), KeyboardButton("👤 My Influencers")],
            [KeyboardButton("🧵 Trails"), KeyboardButton("📊 Analytics")],
            [KeyboardButton("⚙️ Settings")],
        ],
        resize_keyboard=True,
        is_persistent=True,
    )
