"""Public X profile lookup via fxTwitter (no login)."""

from __future__ import annotations

from typing import Any, Dict, List, Optional

import httpx

FX_BASE = "https://api.fxtwitter.com"
UA = (
    "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
)


def clean_handle(raw: str) -> str:
    text = (raw or "").strip()
    if not text or text.startswith("#"):
        return ""
    text = text.lstrip("@")
    text = text.split("/")[0].split("?")[0].strip()
    text = "".join(ch for ch in text if ch.isalnum() or ch == "_")
    if len(text) < 1 or len(text) > 30:
        return ""
    return text


async def _get(path: str) -> Dict[str, Any]:
    async with httpx.AsyncClient(timeout=14.0, headers={"User-Agent": UA, "Accept": "application/json"}) as client:
        res = await client.get(f"{FX_BASE}{path}")
        if res.status_code == 404:
            raise LookupError("Account not found")
        if res.status_code == 429:
            raise RuntimeError("Rate limited — try again shortly")
        if res.status_code >= 400:
            raise RuntimeError(f"Lookup failed ({res.status_code})")
        return res.json()


def _bigger_avatar(url: Optional[str]) -> Optional[str]:
    if not url:
        return None
    return url.replace("_normal.", "_bigger.")


async def fetch_profile(handle: str) -> Dict[str, Any]:
    handle = clean_handle(handle)
    if not handle:
        raise ValueError("Invalid username")
    data = await _get(f"/2/profile/{handle}")
    user = data.get("user") or {}
    screen = user.get("screen_name")
    if not screen:
        raise LookupError("Account not found")
    return {
        "handle": screen,
        "display_name": user.get("name") or screen,
        "avatar_url": _bigger_avatar(user.get("avatar_url")),
        "bio": user.get("description"),
        "followers_count": user.get("followers"),
        "following_count": user.get("following"),
        "verified": bool((user.get("verification") or {}).get("verified")),
    }


async def fetch_replies(handle: str, count: int = 30) -> List[Dict[str, Any]]:
    handle = clean_handle(handle)
    data = await _get(f"/2/profile/{handle}/statuses?count={count}&with_replies=1")
    out: List[Dict[str, Any]] = []
    for item in data.get("results") or []:
        author = ((item.get("author") or {}).get("screen_name") or "")
        if author.lower() != handle.lower():
            continue
        reply_to = item.get("replying_to") or {}
        reply_name = reply_to.get("screen_name")
        if not reply_name or reply_name.lower() == handle.lower():
            continue
        tweet_id = str(item.get("id") or "")
        text = (item.get("text") or "").strip()
        if not tweet_id or not text:
            continue
        out.append(
            {
                "kind": "reply",
                "event_id": f"reply:{tweet_id}",
                "handle": handle,
                "handle_lower": handle.lower(),
                "tweet_id": tweet_id,
                "comment_text": text,
                "timestamp": item.get("created_at"),
                "post_url": item.get("url") or f"https://x.com/{handle}/status/{tweet_id}",
                "reply_to_user": reply_name,
                "reply_to_url": reply_to.get("url") or f"https://x.com/{reply_name}",
            }
        )
    return out


async def fetch_following(handle: str, count: int = 80) -> List[Dict[str, Any]]:
    handle = clean_handle(handle)
    data = await _get(f"/2/profile/{handle}/following?count={count}")
    out: List[Dict[str, Any]] = []
    seen = set()
    for user in data.get("results") or []:
        screen = user.get("screen_name")
        if not screen:
            continue
        key = screen.lower()
        if key in seen or key == handle.lower():
            continue
        seen.add(key)
        out.append(
            {
                "kind": "follow",
                "handle": handle,
                "handle_lower": handle.lower(),
                "followed_user": screen,
                "followed_name": user.get("name") or screen,
                "followed_url": user.get("url") or f"https://x.com/{screen}",
            }
        )
    return out
