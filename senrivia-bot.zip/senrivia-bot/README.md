# Senrivia Bot

**Where influencers leave a trail.**

Professional Telegram bot that tracks public X accounts for:

- Replies left on other people’s posts
- New accounts they start following

Includes MongoDB storage, pause/resume tracking, scheduled scraping, Telegram admin tools, and a protected web admin dashboard.

---

## Features

| Area | Capability |
|------|------------|
| **Users** | `/start` registers every new user in MongoDB |
| **Search** | Look up public profiles via fxTwitter (no X login) |
| **Watchlist** | Add, remove, **pause**, and **resume** tracking |
| **Trails** | See mapped replies and new follows |
| **Alerts** | Optional notifications when new marks appear |
| **Analytics** | Personal tracking stats |
| **Admin (Telegram)** | `/admin` overview, recent users, top tracked |
| **Admin (Web)** | Dashboard: user counts, watch load, recent joins |

---

## Quick start

### 1. Environment

Copy `.env.example` → `.env` and fill values:

```bash
cp .env.example .env
```

| Variable | Required | Description |
|----------|----------|-------------|
| `BOT_TOKEN` | Yes | From [@BotFather](https://t.me/BotFather) |
| `ADMIN_IDS` | Recommended | Comma-separated Telegram user IDs |
| `MONGODB_URI` | Yes | MongoDB connection string |
| `MONGODB_DB` | No | Database name (default `senrivia`) |
| `ADMIN_SECRET` | Yes for web UI | Bearer token for the admin dashboard |
| `ADMIN_HOST` / `ADMIN_PORT` | No | Default `0.0.0.0:8090` |
| `SCRAPE_INTERVAL_MINUTES` | No | Default `15` |

### 2. Install

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

### 3. Run

```bash
python run.py
```

- Telegram bot starts polling  
- Admin dashboard: `http://localhost:8090`  
  Header: `Authorization: Bearer <ADMIN_SECRET>`  
  or `X-Admin-Secret: <ADMIN_SECRET>`

---

## Bot menu

```
👋 Welcome to Senrivia
Where influencers leave a trail.

🔎 Search Influencer
👤 My Influencers    🧵 View Trails
🔔 Alerts            📊 Analytics
⚙️ Settings
```

### Commands

| Command | Description |
|---------|-------------|
| `/start` | Welcome + main menu |
| `/search @user` | Search a public username |
| `/watchlist` | Your influencers |
| `/trails` | Recent trail marks |
| `/analytics` | Your stats |
| `/settings` | Alerts on/off |
| `/admin` | Admin console (ADMIN_IDS only) |
| `/stats` | Quick admin numbers |

---

## Architecture

```
TELEGRAM USER
      │
      ▼
SENRIVIA BOT  ──►  Service layer
                      │
           ┌──────────┼──────────┐
           ▼          ▼          ▼
        MongoDB    Scraper    Alerts
                      │
                 fxTwitter API
```

Background worker scans **active** (non-paused) handles on an interval and stores new trail events. Users with alerts enabled are notified.

---

## Admin dashboard capabilities

- Total users who joined the bot  
- Who is tracking what (watch rows, active vs paused)  
- Top tracked influencers  
- Recent user list (Telegram ID, username, join time)  
- JSON APIs: `/api/stats`, `/api/users`

---

## Project layout

```
senrivia-bot/
├── run.py                 # Entrypoint
├── .env.example
├── requirements.txt
├── bot/                   # Telegram handlers, keyboards, config
├── database/              # MongoDB + repositories
├── scraper/               # fxTwitter client
├── services/              # Domain logic
├── workers/               # Scheduled scrape + alerts
└── admin/                 # FastAPI dashboard
```

---

## Notes

- Only **public** X data is used (fxTwitter). No user X passwords.
- First watch of an account builds a **follow baseline** so existing follows are not treated as “new”.
- Pause an influencer anytime — they stay on the list but are skipped by the worker.

---

## License

Private project — all rights reserved unless otherwise stated by the owner.
