"""Trail formatting helpers."""

from __future__ import annotations

from typing import Any, Dict, List


def format_trail_lines(events: List[Dict[str, Any]], limit: int = 12) -> str:
    if not events:
        return "_No trail marks yet. Scan or wait for the next scheduled pass._"
    lines: List[str] = []
    for ev in events[:limit]:
        kind = ev.get("kind")
        handle = ev.get("handle") or "?"
        if kind == "reply":
            target = ev.get("reply_to_user") or "someone"
            text = (ev.get("comment_text") or "").replace("\n", " ")
            if len(text) > 140:
                text = text[:137] + "…"
            lines.append(f"• **@{handle}** replied to **@{target}**\n  _{text}_")
        elif kind == "follow" and ev.get("is_new"):
            followed = ev.get("followed_user") or "?"
            name = ev.get("followed_name") or followed
            lines.append(f"• **@{handle}** started following **{name}** (@{followed})")
        else:
            continue
    if not lines:
        return "_No new trail marks yet._"
    return "\n\n".join(lines)
