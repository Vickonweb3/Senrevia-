"""User-facing analytics summaries."""

from __future__ import annotations

from typing import Any, Dict

from database import repositories as repo


def user_analytics(telegram_id: int) -> Dict[str, Any]:
    watch = repo.list_watchlist(telegram_id)
    active = sum(1 for w in watch if not w.get("paused"))
    paused = sum(1 for w in watch if w.get("paused"))
    trails = repo.list_trails_for_user(telegram_id, limit=200)
    replies = sum(1 for t in trails if t.get("kind") == "reply")
    follows = sum(1 for t in trails if t.get("kind") == "follow" and t.get("is_new"))
    return {
        "tracked": len(watch),
        "active": active,
        "paused": paused,
        "replies": replies,
        "new_follows": follows,
    }
