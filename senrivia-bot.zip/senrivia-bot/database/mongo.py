"""MongoDB connection helpers."""

from __future__ import annotations

from typing import Optional

from pymongo import ASCENDING, DESCENDING, MongoClient, ReturnDocument
from pymongo.database import Database

from bot.config import get_settings

_client: Optional[MongoClient] = None
_db: Optional[Database] = None


def init_db() -> Database:
    global _client, _db
    settings = get_settings()
    _client = MongoClient(settings.mongodb_uri, serverSelectionTimeoutMS=8000)
    _client.admin.command("ping")
    _db = _client[settings.mongodb_db]
    _ensure_indexes(_db)
    return _db


def get_db() -> Database:
    global _db
    if _db is None:
        return init_db()
    return _db


def close_db() -> None:
    global _client, _db
    if _client is not None:
        _client.close()
    _client = None
    _db = None


def _ensure_indexes(db: Database) -> None:
    db.users.create_index("telegram_id", unique=True)
    db.users.create_index([("joined_at", DESCENDING)])
    db.watchlist.create_index([("telegram_id", ASCENDING), ("handle_lower", ASCENDING)], unique=True)
    db.watchlist.create_index([("paused", ASCENDING), ("handle_lower", ASCENDING)])
    db.trails.create_index([("event_id", ASCENDING)], unique=True)
    db.trails.create_index([("handle_lower", ASCENDING), ("created_at", DESCENDING)])
    db.trails.create_index([("telegram_id", ASCENDING), ("created_at", DESCENDING)])
    db.alerts.create_index([("telegram_id", ASCENDING), ("created_at", DESCENDING)])
    db.scrape_log.create_index([("created_at", DESCENDING)])
