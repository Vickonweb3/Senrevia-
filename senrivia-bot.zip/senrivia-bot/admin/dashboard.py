"""Lightweight FastAPI admin dashboard for Senrivia."""

from __future__ import annotations

from typing import Optional

from fastapi import Depends, FastAPI, Header, HTTPException, Request
from fastapi.responses import HTMLResponse
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from bot.config import get_settings
from database import repositories as repo

security = HTTPBearer(auto_error=False)


def create_admin_app() -> FastAPI:
    app = FastAPI(title="Senrivia Admin", docs_url=None, redoc_url=None)

    def require_admin(
        authorization: Optional[HTTPAuthorizationCredentials] = Depends(security),
        x_admin_secret: Optional[str] = Header(default=None),
    ) -> None:
        settings = get_settings()
        expected = settings.admin_secret
        if not expected:
            # If no secret configured, lock down completely
            raise HTTPException(status_code=503, detail="ADMIN_SECRET is not configured")
        token = None
        if authorization and authorization.scheme.lower() == "bearer":
            token = authorization.credentials
        if x_admin_secret:
            token = x_admin_secret
        if token != expected:
            raise HTTPException(status_code=401, detail="Unauthorized")

    @app.get("/", response_class=HTMLResponse)
    def home(_: None = Depends(require_admin)) -> str:
        stats = repo.admin_stats()
        users = repo.list_users(limit=40)
        rows = []
        for u in users:
            uname = u.get("username") or "—"
            name = " ".join(filter(None, [u.get("first_name"), u.get("last_name")])) or "—"
            joined = u.get("joined_at")
            watches = len(repo.list_watchlist(u["telegram_id"]))
            rows.append(
                f"<tr><td>{u.get('telegram_id')}</td><td>@{uname}</td><td>{name}</td>"
                f"<td>{joined}</td><td>{watches}</td></tr>"
            )
        top = "".join(
            f"<li>@{t.get('handle')} — {t.get('count')} watchers</li>"
            for t in (stats.get("top_tracked") or [])
        ) or "<li>None yet</li>"
        return f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <title>Senrivia Admin</title>
  <style>
    :root {{ color-scheme: dark; --bg:#0c0d0c; --fg:#ece8e0; --muted:#8a8e88; --card:#161816; --line:rgba(236,232,224,.12); }}
    body {{ margin:0; font-family: ui-sans-serif, system-ui, sans-serif; background:var(--bg); color:var(--fg); }}
    main {{ max-width: 1100px; margin: 0 auto; padding: 2rem 1.25rem 4rem; }}
    h1 {{ font-weight: 600; letter-spacing: -0.02em; }}
    .sub {{ color: var(--muted); margin-top: .35rem; }}
    .grid {{ display:grid; grid-template-columns: repeat(auto-fit,minmax(160px,1fr)); gap: .75rem; margin: 1.5rem 0 2rem; }}
    .card {{ background: var(--card); border: 1px solid var(--line); border-radius: 14px; padding: 1rem 1.1rem; }}
    .card .n {{ font-size: 1.6rem; font-variant-numeric: tabular-nums; }}
    .card .l {{ color: var(--muted); font-size: .75rem; text-transform: uppercase; letter-spacing: .12em; margin-top: .25rem; }}
    table {{ width:100%; border-collapse: collapse; font-size: .92rem; }}
    th, td {{ text-align:left; padding: .65rem .4rem; border-bottom: 1px solid var(--line); }}
    th {{ color: var(--muted); font-weight: 500; font-size: .75rem; text-transform: uppercase; letter-spacing: .08em; }}
    h2 {{ margin-top: 2rem; font-size: 1.15rem; }}
    ul {{ color: var(--muted); }}
  </style>
</head>
<body>
<main>
  <h1>Senrivia Admin</h1>
  <p class="sub">Where influencers leave a trail — operations overview</p>
  <div class="grid">
    <div class="card"><div class="n">{stats['users_total']}</div><div class="l">Users</div></div>
    <div class="card"><div class="n">{stats['watch_total']}</div><div class="l">Watch rows</div></div>
    <div class="card"><div class="n">{stats['watch_active']}</div><div class="l">Active</div></div>
    <div class="card"><div class="n">{stats['watch_paused']}</div><div class="l">Paused</div></div>
    <div class="card"><div class="n">{stats['trails_total']}</div><div class="l">Trail events</div></div>
  </div>
  <h2>Top tracked accounts</h2>
  <ul>{top}</ul>
  <h2>Recent users</h2>
  <table>
    <thead><tr><th>Telegram ID</th><th>Username</th><th>Name</th><th>Joined</th><th>Watching</th></tr></thead>
    <tbody>{''.join(rows) or '<tr><td colspan="5">No users yet</td></tr>'}</tbody>
  </table>
</main>
</body>
</html>"""

    @app.get("/api/stats")
    def api_stats(_: None = Depends(require_admin)) -> dict:
        return repo.admin_stats()

    @app.get("/api/users")
    def api_users(limit: int = 50, skip: int = 0, _: None = Depends(require_admin)) -> list:
        return [
            {
                "telegram_id": u.get("telegram_id"),
                "username": u.get("username"),
                "first_name": u.get("first_name"),
                "last_name": u.get("last_name"),
                "joined_at": str(u.get("joined_at")),
                "last_active_at": str(u.get("last_active_at")),
            }
            for u in repo.list_users(limit=limit, skip=skip)
        ]

    return app
