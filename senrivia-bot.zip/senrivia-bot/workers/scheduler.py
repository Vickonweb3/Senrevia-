"""Scheduled scrape worker for active watchlists."""

from __future__ import annotations

import asyncio
import logging
from typing import Optional, Set

from apscheduler.schedulers.asyncio import AsyncIOScheduler
from telegram.ext import Application

from bot.config import get_settings
from database import repositories as repo
from scraper import fetch_following, fetch_replies

log = logging.getLogger("senrivia.worker")
_scheduler: Optional[AsyncIOScheduler] = None


async def _scan_handle(app: Application, handle: str) -> None:
    try:
        replies = await fetch_replies(handle)
        following = await fetch_following(handle)
    except Exception as exc:  # noqa: BLE001
        repo.touch_watch_scan(handle, error=str(exc))
        repo.log_scrape(str(exc), level="error", handle=handle)
        return

    new_reply_ids: Set[str] = set()
    for row in replies:
        inserted = repo.insert_trail_event({**row, "is_new": True})
        if inserted:
            new_reply_ids.add(row["event_id"])

    # follows: only mark new if we have prior baseline (non-baseline exists or any prior)
    prior = repo.list_trails_for_handle(handle, limit=5)
    has_history = any(t.get("kind") == "follow" for t in prior)
    new_follow_events = []
    for row in following:
        event_id = f"follow:{handle.lower()}:{row['followed_user'].lower()}"
        payload = {**row, "event_id": event_id, "is_new": has_history, "baseline": not has_history}
        if repo.insert_trail_event(payload) and has_history:
            new_follow_events.append(payload)

    repo.touch_watch_scan(handle)
    repo.log_scrape(
        f"scanned replies={len(replies)} follows={len(following)} new_replies={len(new_reply_ids)} new_follows={len(new_follow_events)}",
        handle=handle,
    )

    # Notify watchers with alerts enabled
    watcher_ids = repo.users_tracking_handle(handle, active_only=True)
    if not watcher_ids:
        return
    notes = []
    if new_reply_ids:
        notes.append(f"{len(new_reply_ids)} new reply mark(s)")
    if new_follow_events:
        notes.append(f"{len(new_follow_events)} new follow(s)")
    if not notes:
        return
    text = f"🔔 *@{handle}*\n" + " · ".join(notes)
    for tid in watcher_ids:
        user = repo.get_user(tid) or {}
        if not (user.get("settings") or {}).get("alerts_enabled", True):
            continue
        try:
            await app.bot.send_message(chat_id=tid, text=text, parse_mode="Markdown")
        except Exception as exc:  # noqa: BLE001
            log.warning("alert failed user=%s: %s", tid, exc)


async def run_round(app: Application) -> None:
    handles = repo.list_active_watch_handles()
    log.info("scrape round starting handles=%s", len(handles))
    for handle in handles:
        await _scan_handle(app, handle)
        await asyncio.sleep(2.5)
    log.info("scrape round complete")


def start_scheduler(app: Application) -> AsyncIOScheduler:
    global _scheduler
    settings = get_settings()
    scheduler = AsyncIOScheduler(timezone="UTC")
    scheduler.add_job(
        run_round,
        "interval",
        minutes=settings.scrape_interval_minutes,
        args=[app],
        id="senrivia_scrape",
        replace_existing=True,
        max_instances=1,
        coalesce=True,
    )
    scheduler.start()
    _scheduler = scheduler
    log.info("scheduler started interval=%s min", settings.scrape_interval_minutes)
    return scheduler


def stop_scheduler() -> None:
    global _scheduler
    if _scheduler:
        _scheduler.shutdown(wait=False)
        _scheduler = None
